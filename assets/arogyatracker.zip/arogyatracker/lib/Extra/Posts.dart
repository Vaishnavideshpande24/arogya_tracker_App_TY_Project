
//class Posts{
//  String image,date,time,name,facility,community;
//  Posts(this.image,this.date,this.time,this.name,this.facility,this.community);
//
//  bool isSelected=false;
//}