import 'package:arogyatracker/Aboutus.dart';
import 'package:arogyatracker/Contactus.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:arogyatracker/authentications.dart';
import 'package:arogyatracker/main.dart';
import 'Adminlogin.dart';
import 'Contactus.dart';
import 'package:arogyatracker/Aboutus.dart';
import 'Extra/PhotoUpload.dart';
import 'maps.dart';


class TasksPage extends StatefulWidget {
  final String uid;

  TasksPage({Key key, @required this.uid}) : super(key: key);

  @override
  _TasksPageState createState() => _TasksPageState(uid);
}

class _TasksPageState extends State<TasksPage> {
  final String uid;
  _TasksPageState(this.uid);

  var taskcollections = Firestore.instance.collection('tasks');
  String task;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor:Colors.white,
        appBar: AppBar(
          elevation: 10.0,
          backgroundColor: Colors.white,
          bottom: TabBar(

            indicatorColor: Colors.black54,
            tabs: [
              Text('Data',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 18.0),),
              Text('Chart',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 18.0),),
              Text('Report',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 18.0),),

            ],
          ),
          actions: <Widget>[
           IconButton(
             icon: Icon(Icons.exit_to_app,color: Colors.black),
             onPressed: () => signOutUser().then((value) {
               Navigator.of(context).pushAndRemoveUntil(
                   MaterialPageRoute(builder: (context) => HomePage()),
                       (Route<dynamic> route) => false);
             }),
           )
          ],
          iconTheme: IconThemeData(color: Colors.black),
        ),
        drawer:Drawer(child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            new Container(
              height: 280.0,

                child: new DrawerHeader(

                   child: Padding(
                     padding: const EdgeInsets.all(32.0),
                     child: FlatButton(
                        onPressed: () {

                        },
                        child: new Icon(
                          Icons.account_box,
                          color: Colors.white,
                          size: 150.0,
                        ),
                        shape: new CircleBorder(),
                        color: Colors.pink[300],
                      ),
                   )
                ),
                color:Colors.pink[300]),
            SizedBox(height: 4.0),
               ListTile(
                leading: Icon(Icons.home,color: Colors.black,size: 25.0,),
                title: Text('Home',
                  style: TextStyle(
                    fontSize: 18.0,
                  ),

                ),
                 onTap: () {
                   Navigator.push(
                     context,
                     MaterialPageRoute(
                       builder: (context) => TasksPage(),
                     ),
                   );
                 },
              ),
            SizedBox(height: 6.0),

            ListTile(
              leading: Icon(Icons.location_on,color: Colors.black,size: 25.0,),
              title: Text('My location',
                style: TextStyle(
                  fontSize: 18.0,
                ),),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Maps(),
                  ),
                );
              },
            ),
               ListTile(
                leading: Icon(Icons.contact_mail,color: Colors.black,size: 25.0,),
                title: Text('Contact us',
                  style: TextStyle(
                    fontSize: 18.0,
                  ),),
                 onTap: () {
                   Navigator.push(
                     context,
                     MaterialPageRoute(
                       builder: (context) => Contactus(),
                     ),
                   );
                 },
              ),

            SizedBox(height: 6.0),
            ListTile(
              leading: Icon(Icons.cancel,color: Colors.black,size: 25.0,),
              title: Text('Cancellation',
                style: TextStyle(
                  fontSize: 18.0,
                ),),
            ),
            SizedBox(height: 6.0),
            ListTile(
              leading: Icon(Icons.question_answer,color: Colors.black,size: 25.0,),
              title: Text('FAQ',
                style: TextStyle(
                  fontSize: 18.0,
                ),),
//
//              onTap: () {
//                Navigator.push(
//                  context,
//                  MaterialPageRoute(
//                    builder: (context) => (),
//                  ),
//                );
//              },
            ),
            SizedBox(height: 6.0),
            ListTile(
              leading: Icon(Icons.info,color: Colors.black,size: 25.0,),
              title: Text('About',
                style: TextStyle(
                  fontSize: 18.0,
                ),),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Aboutus(),
                  ),
                );
              },
            ),
            SizedBox(height: 6.0),
            ListTile(
              leading: Icon(Icons.person_add,color: Colors.black,size: 25.0,),
              title: Text('Admin Login',
                style: TextStyle(
                  fontSize: 18.0,
                ),),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LoginPage(),
                  ),
                );
              },
            ),
          ],
        ),
        ),
        body: TabBarView(
          children: [
            Icon(Icons.person),
            Icon(Icons.insert_chart),
            Icon(Icons.mode_edit),

          ],
        ),
      ),
    );
  }}