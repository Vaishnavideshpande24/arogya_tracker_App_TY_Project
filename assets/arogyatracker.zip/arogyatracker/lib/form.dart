import 'package:arogyatracker/Adminlogin.dart';
import 'package:arogyatracker/tasks.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class TasksPages extends StatefulWidget {
  final String uid;

  TasksPages({Key key, @required this.uid}) : super(key: key);

  @override
  _TasksPagesState createState() => _TasksPagesState(uid);
}

class _TasksPagesState extends State<TasksPages> {
  final String uid;
  _TasksPagesState(this.uid);

  var taskcollections = Firestore.instance.collection('tasks');
  String task; //Name
  String history;

  void showdialog(bool isUpdate, DocumentSnapshot ds) {
    GlobalKey<FormState> formkey = GlobalKey<FormState>();

    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: isUpdate ? Text("Update Data") : Text("Migrant's Data"),
            content: Form(
              key: formkey,
              autovalidate: true,
              child: Column(
                children: <Widget>[
                  TextFormField(
                    autofocus: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Migrant Name",
                    ),
                    validator: (_val) {
                      if (_val.isEmpty) {
                        return "Can't Be Empty";
                      } else {
                        return null;
                      }
                    },
                    onChanged: (_val) {
                      task = _val;
                    },
                  ),
                  SizedBox(height: 15.0),
                  TextFormField(
                    autofocus: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Phone number",
                    ),
                    validator: (_val1) {
                      if (_val1.isEmpty) {
                        return "Can't Be Empty";
                      } else {
                        return null;
                      }
                    },
                    onChanged: (_val1) {
                      history = _val1;
                    },

                  ),
                ],
              ),
            ),
            actions: <Widget>[
              RaisedButton(
                color: Colors.purple,
                onPressed: () {
                  if (formkey.currentState.validate()) {
                    formkey.currentState.save();
                    if (isUpdate) {
                      taskcollections
                          .document(uid)
                          .collection('task')
                          .document(ds.documentID)
                          .updateData({
                        'task': task,
                        'history':history,
                        'time': DateTime.now(),
                      });
                    } else {
                      //  insert
                      taskcollections.document(uid).collection('task').add({
                        'task': task,
                        'history':history,
                        'time': DateTime.now(),
                      });
                    }
                    Navigator.pop(context);
                  }
                },
                child: Text(
                  "Add",
                  style: TextStyle(
                    fontFamily: "tepeno",
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () => showdialog(false, null),
        child: Icon(Icons.add),
      ),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1.0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios,color: Colors.black,),
          onPressed: (){
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => LoginPage(),
              ),
            );
          },
        ),

        title: Text(
          'Migrant Data',
          style: TextStyle(
            fontFamily: "Pacifico",
            color: Colors.black,


          ),
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.exit_to_app),
            splashColor: Colors.transparent,
            highlightColor: Colors.black,
            onPressed: (){
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TasksPage(),
                ),
              );
            },
          ),
        ],

      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: taskcollections
            .document(uid)
            .collection('task')
            .orderBy('time')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data.documents.length,
              itemBuilder: (context, index) {
                DocumentSnapshot ds = snapshot.data.documents[index];
                DocumentSnapshot ds1 = snapshot.data.documents[index];


                return Container(
                  decoration: BoxDecoration(
                    color: Colors.purpleAccent,
                    borderRadius: BorderRadius.circular(5.0),
                  ),
                  margin: EdgeInsets.all(8.0),
                  child: ListTile(
                    title: Column(
                      children: <Widget>[
                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Name:'+'   '+"  "+ds['task'].toString().toUpperCase(),
                            style: TextStyle(

                              fontSize: 20.0,
                              color: Colors.white,
                            ),
                          ),
                        ),
                        SizedBox(height: 8.0),
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Text(
                            'Phone no-:'+'  '+"  "+ds1['history'],
                            style: TextStyle(

                              fontSize: 20.0,
                              color: Colors.black,
                            ),
                          ),
                        ),



                      ],
                    ),
                    onLongPress: () {
                      // delete
                      taskcollections
                          .document(uid)
                          .collection('task')
                          .document(ds.documentID)
                          .delete();
                    },
                    onTap: () {
                      // == Update
                      showdialog(true, ds);
                    },
                  ),
                );
              },
            );
          } else if (snapshot.hasError) {
            return CircularProgressIndicator();
          } else {
            return CircularProgressIndicator();
          }
        },
      ),
    );
  }
}
